exports.getAboutPage = (req, res) => {
    res.render('about'); // Render about.ejs
};
